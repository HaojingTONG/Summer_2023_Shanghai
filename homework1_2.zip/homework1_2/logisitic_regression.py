# import numpy as np


# def sigmoid(x):
#     return 1 / (1 + np.exp(-x))


# class LogisticReg(object):
#     def __init__(self, indim=1):
#             # initialize the parameters with all zeros
#             # w: shape of [d+1, 1]
#         self.w = np.zeros((indim + 1,1))
#         # print(self.w)
#         # print(self.w.shape)
    
#     def set_param(self, weights, bias):
#         # helper function to set the parameters
#         # NOTE: you need to implement this to pass the autograde.
#         # weights: vector of shape [d, ]
#         # bias: scaler
#         self.w[:-1] = weights.reshape(-1,1)
#         self.w[-1] = bias
    
#     def get_param(self):
#         # helper function to return the parameters
#         # NOTE: you need to implement this to pass the autograde.
#         # returns:
#             # weights: vector of shape [d, ]
#             # bias: scaler
#         return self.w[:-1], self.w[-1]

#     def compute_loss(self, X, t):
#         # compute the loss
#         # X: feature matrix of shape [N, d]
#         # t: input label of shape [N, ]
#         # NOTE: return the average of the log-likelihood, NOT the sum.

#         # extend the input matrix
#         X_extend = np.concatenate((X, np.ones((X.shape[0], 1))), axis=1)
#         y = sigmoid(np.dot(X_extend, self.w))
#         # compute the loss and return the loss
#         loss = -np.mean(t * np.log(y) + (1 - t) * np.log(1 - y))
#         # print(loss)
#         return loss


#     def compute_grad(self, X, t):
#         # X: feature matrix of shape [N, d]
#         # grad: shape of [d, 1]
#         # NOTE: return the average gradient, NOT the sum.
#         X_extend = np.concatenate((X, np.ones((X.shape[0], 1))), axis=1)
#         y = sigmoid(np.dot(X_extend, self.w))
#         # print(gd)
#         grad = np.mean(np.dot((y-t), X_extend), axis=0).reshape(-1, 1)
#         print(grad)
#         return grad


#     def update(self, grad, lr=0.001):
#         # update the weights
#         # by the gradient descent rule
        
#         self.w -= lr * grad


#     def fit(self, X, t, lr=0.001, max_iters=1000, eps=1e-7):
#         # implement the .fit() using the gradient descent method.
#         # args:
#         #   X: input feature matrix of shape [N, d]
#         #   t: input label of shape [N, ]
#         #   lr: learning rate
#         #   max_iters: maximum number of iterations
#         #   eps: tolerance of the loss difference 
#         # TO NOTE: 
#         #   extend the input features before fitting to it.
#         #   return the weight matrix of shape [indim+1, 1]

#         t = t.reshape(-1,1)
#         loss = 1e10
#         for epoch in range(max_iters):
#             # compute the loss 
#             new_loss = self.compute_loss(X, t)
            
#             if np.abs(new_loss - loss) < eps:
#                 break

#             loss = new_loss

#             # compute the gradient
#             grad = self.compute_grad(X, t)

#             # update the weight
#             self.update(grad, lr=lr)

#         return self.w


#     def predict_prob(self, X):
#         # implement the .predict_prob() using the parameters learned by .fit()
#         # X: input feature matrix of shape [N, d]
#         #   NOTE: make sure you extend the feature matrix first,
#         #   the same way as what you did in .fit() method.
#         # returns the prediction (likelihood) of shape [N, ]
#         X_extend = np.concatenate((X, np.ones((X.shape[0], 1))), axis=1)
#         return sigmoid(np.dot(X_extend, self.w))

    
#     def predict(self, X, threshold=0.5):
#         # implement the .predict() using the .predict_prob() method
#         # X: input feature matrix of shape [N, d]
#         # returns the prediction of shape [N, ], where each element is -1 or 1.
#         # if the probability p>threshold, we determine t=1, otherwise t=-1
#         prob = self.predict_prob(X)
#         larger_or_less = np.where(prob > threshold, 1, -1)
#         return larger_or_less

import numpy as np

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

class LogisticReg(object):
    def __init__(self, indim=1):
        self.w = np.zeros((indim+1, 1))
        print(self.w.shape)

    def set_param(self, weights, bias):
        self.w = np.hstack((bias, weights)).reshape(-1, 1)

    def get_param(self):
        return self.w[1:].flatten(), self.w[0].item()

    def compute_loss(self, X, t):
        X_ext = np.hstack((np.ones((X.shape[0], 1)), X))
        z = np.dot(X_ext, self.w)
        pred = sigmoid(z)
        loss = -np.mean(t * np.log(pred) + (1 - t) * np.log(1 - pred))
        return loss

    def compute_grad(self, X, t):
        X_ext = np.hstack((np.ones((X.shape[0], 1)), X))  # Shape (N, d+1)
        z = np.dot(X_ext, self.w)                         # Shape (N, 1)
        pred = sigmoid(z)   
        grad = np.mean(np.dot((pred - t), X_ext), axis=0).reshape(-1, 1)                              # Shape (N, 1)
          # Should result in Shape (d+1, 1)
        print(grad.shape)
        return grad

    def update(self, grad, lr=0.001):
        self.w -= lr * grad

    def fit(self, X, t, lr=0.001, max_iters=1000, eps=1e-7):
        loss = 1e10
        for _ in range(max_iters):
            new_loss = self.compute_loss(X, t)
            if np.abs(new_loss - loss) < eps:
                return self.w
            loss = new_loss
            grad = self.compute_grad(X, t)
            self.update(grad, lr)

    def predict_prob(self, X):
        X_ext = np.hstack((np.ones((X.shape[0], 1)), X))
        z = np.dot(X_ext, self.w)
        pred = sigmoid(z)
        return pred.flatten()

    def predict(self, X, threshold=0.5):
        probs = self.predict_prob(X)
        return (probs > threshold).astype(int) * 2 - 1