import numpy as np

def second_order_basis(X):
    # Initialize an empty list
    result = []
    # Iterate each sample in X
    for row in X:
        # Initialize an empty list to store the second_order_basis
        second_order_basis = []
        # Iterate each elements in row
        for i in range(len(row)):
            for j in range(i, len(row)):
                # Calculate the the products of each element at indices i and j
                products = row[i] * row[j]
                
                # add it to the list
                second_order_basis.append(products)
        
        # Append the second order basis to the result list
        result.append(second_order_basis)
        
    # Return the result as an  numpy array
    return np.array(result)

class LinearReg:
    def __init__(self, indim, outdim):
        self.indim = indim
        self.outdim = outdim
        self.W = None
        
    def fit(self, X, T):
        # Parameters X: numpy array, (n_samples, n_features)  Training data
        #            T: numpy array, (n_samples, n_targets)   Target values
        # Combine a column of ones at the end of matrix
        X = np.hstack((X, np.ones((X.shape[0], 1))))
        
        # Calculate the W
        self.W  = np.linalg.inv(X.T.dot(X)).dot(X.T).dot(T)
        
    def predict(self,X):
        # Combine a column of ones at the end of matrix
        X = np.hstack((X, np.ones((X.shape[0], 1))))
        
        # Return the predicted values
        return X.dot(self.W)